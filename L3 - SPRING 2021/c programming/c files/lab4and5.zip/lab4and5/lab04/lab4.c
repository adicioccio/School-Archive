/*  
* Title: Lab Assessment 4 and 6
* Course: CST8234 C Language 
* @Author: Adam Di Cioccio (041019241) and Mike Zhigun(040999914)
* Lab Section: 011 
* Professor: Surbhi Bahri 
* Due date: 11/29/21
* Submission date: 11/26/21  
*/

/*include header and code*/
#include "header.h"
#include "code.c"

/*main method*/
int main() {
    playGame();
}