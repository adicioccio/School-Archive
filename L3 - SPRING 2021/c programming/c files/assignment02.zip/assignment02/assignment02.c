/*includes*/
#include "header.h"
#include "code.c"

/*main*/
int main (int argc, char *argv[]) {
    runProgram();
}